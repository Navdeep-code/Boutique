</main>
    <footer class="content-wrapper" id="footer">
      <div class="footerfields">
        <div id="apps"><a href="#" aria-label="Twitter"><i class="fa-brands fa-twitter"></i></a><a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a><a href="#" aria-label="Mail"><i class="fa-sharp fa-solid fa-envelope"></i></a></div>
        <form id="main-form" action="#" method="post">
          <label for="mail">Join our mailing list for updates</label>
          <input id="mail" type="email" placeholder="janedoe@gmail.com">
          <input id="signup" type="submit" value="Sign up">
        </form>
      </div>
      <p>&copy; Copyright HTTP 5212, 2023.</p>
    </footer>
</body>
</html>