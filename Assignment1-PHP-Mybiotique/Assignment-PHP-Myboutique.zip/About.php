<?php
  //Including the files
  include( 'includes/database.php' );
  include( 'includes/header.php' );
?>
<div class="contentbox">
  <h1 class="page-title"> Who we are </h1>
  <p id="abouttext"> Our Boutique Exquisiteify has been ruling over Toronto's heart for five years now.We have now expanded our business and opened new stores in Brampton and Mississauga as well.We provide quality products keeping the latest trends in mind at reasonable prices.</p>
  <a id="learn" href="#"> Learn more</a>
</div>

<?php
//Including the files
include( 'includes/footer.php');     
?>